#include <iostream>
#include <string>
#include <algorithm>

class Product {
public:
    std::string name;
    int quantity;
    double price;
    std::string otherDetails;
    std::string purchaseDate;
    std::string supplier;

    Product(const std::string &name, int quantity, double price, const std::string &details,
            const std::string &purchaseDate, const std::string &supplier)
        : name(name), quantity(quantity), price(price), otherDetails(details),
          purchaseDate(purchaseDate), supplier(supplier) {}
};

class Inventory {
private:
    static const int MAX_PRODUCTS = 100;
    Product* products[MAX_PRODUCTS];
    int itemCount;

public:
    Inventory() : itemCount(0) {
        for (int i = 0; i < MAX_PRODUCTS; ++i) {
            products[i] = NULL; // Initialize pointers to NULL
        }
    }

    ~Inventory() {
        for (int i = 0; i < itemCount; ++i) {
            delete products[i]; // Deallocate memory
        }
    }

    void addProduct(const std::string &name, int quantity, double price, const std::string &details,
                    const std::string &purchaseDate, const std::string &supplier) {
        if (itemCount < MAX_PRODUCTS) {
            products[itemCount] = new Product(name, quantity, price, details, purchaseDate, supplier);
            itemCount++;
        } else {
            std::cout << "Inventory is full. Cannot add more products." << std::endl;
        }
    }

    void removeProduct(const std::string &name, int quantity) {
        for (int i = 0; i < itemCount; ++i) {
            if (products[i]->name == name) {
                if (products[i]->quantity >= quantity) {
                    products[i]->quantity -= quantity;
                    if (products[i]->quantity == 0) {
                        delete products[i]; // Deallocate memory
                        for (int j = i; j < itemCount - 1; ++j) {
                            products[j] = products[j + 1];
                        }
                        products[itemCount - 1] = NULL;
                        itemCount--;
                    }
                } else {
                    std::cout << "Not enough " << name << " in inventory." << std::endl;
                }
                return;
            }
        }
        std::cout << name << " not found in inventory." << std::endl;
    }

    void displayInventory() {
        std::cout << "Inventory:" << std::endl;
        for (int i = 0; i < itemCount; ++i) {
            const Product &product = *(products[i]);
            std::cout << "Name: " << product.name << ", Quantity: " << product.quantity
                      << ", Price: " << product.price << ", Details: " << product.otherDetails
                      << ", Purchase Date: " << product.purchaseDate << ", Supplier: " << product.supplier << std::endl;
        }
    }

    void displayMenu() {
        std::cout << "Menu:" << std::endl;
        std::cout << "1. Add Product" << std::endl;
        std::cout << "2. Remove Product" << std::endl;
        std::cout << "3. Display Inventory" << std::endl;
        std::cout << "4. Exit" << std::endl;
    }

    void run() {
        int choice;
        while (true) {
            displayMenu();
            std::cout << "Enter your choice: ";
            std::cin >> choice;

            switch (choice) {
                case 1: {
                    std::string name, details, purchaseDate, supplier;
                    int quantity;
                    double price;
                    std::cout << "Enter product name: ";
                    std::cin >> name;
                    std::cout << "Enter quantity: ";
                    std::cin >> quantity;
                    std::cout << "Enter price: ";
                    std::cin >> price;
                    std::cout << "Enter details: ";
                    std::cin.ignore();
                    std::getline(std::cin, details);
                    std::cout << "Enter purchase date: ";
                    std::getline(std::cin, purchaseDate);
                    std::cout << "Enter supplier: ";
                    std::getline(std::cin, supplier);
                    addProduct(name, quantity, price, details, purchaseDate, supplier);
                    break;
                }
                case 2: {
                    std::string name;
                    int quantity;
                    std::cout << "Enter product name: ";
                    std::cin >> name;
                    std::cout << "Enter quantity to remove: ";
                    std::cin >> quantity;
                    removeProduct(name, quantity);
                    break;
                }
                case 3:
                    displayInventory();
                    break;
                case 4:
                    return;
                default:
                    std::cout << "Invalid choice. Please enter a valid option." << std::endl;
            }
        }
    }
};

int main() {
    Inventory inventory;

    inventory.run();

    return 0;
}

